package Gestion_de_note;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Gestion_de_note extends JFrame {

	private JPanel contentPane;
	private JFrame frame;
	private JTextField textnom;
	private JTextField textpr;
	private JTextField textcin;
	private JTextField textds;
	private JTextField textex;
	private JTable table;
	private JTextField r;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gestion_de_note frame = new Gestion_de_note();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gestion_de_note() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1400, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//new jPanel
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(240, 255, 255));
		panel_1.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(176, 224, 230)));//bordure exterieur
		panel_1.setBounds(10, 10, 1360, 700);//largeur bordure 
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		//new jPanel
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(176, 224, 230)));//bordure gestion de note
		panel_1_1.setBackground(new Color(240, 255, 255));
		panel_1_1.setBounds(39, 34, 1264, 91);//largeur bordure 
		panel_1.add(panel_1_1);
		
		JLabel lblNewLabel = new JLabel("Gestion de note");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
		lblNewLabel.setBounds(390, 21, 424, 49);
		panel_1_1.add(lblNewLabel);
		//new jPanel
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setLayout(null);
		panel_1_1_1.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(176, 224, 230)));//bordure zone de saisie
		panel_1_1_1.setBackground(new Color(240, 255, 220));
		panel_1_1_1.setBounds(39, 167, 627, 347);
		panel_1.add(panel_1_1_1);
		//nom
		JLabel lblNewLabel_1 = new JLabel("Nom");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(29, 28, 91, 30);
		panel_1_1_1.add(lblNewLabel_1);
		//prenom
		JLabel lblNewLabel_1_1 = new JLabel("Prenom");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1_1.setBounds(29, 68, 91, 30);
		panel_1_1_1.add(lblNewLabel_1_1);
		//cin
		JLabel lblNewLabel_1_2 = new JLabel("Cin");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1_2.setBounds(29, 108, 91, 30);
		panel_1_1_1.add(lblNewLabel_1_2);
		//groupe
		JLabel lblNewLabel_1_3 = new JLabel("Groupe");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1_3.setBounds(29, 146, 91, 30);
		panel_1_1_1.add(lblNewLabel_1_3);
		//matiere
		JLabel lblNewLabel_1_4 = new JLabel("Mati\u00E8re");
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1_4.setBounds(29, 186, 91, 30);
		panel_1_1_1.add(lblNewLabel_1_4);
		//note ds
		JLabel lblNewLabel_1_5 = new JLabel("Note Ds");
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1_5.setBounds(29, 227, 91, 30);
		panel_1_1_1.add(lblNewLabel_1_5);
		//note examen
		JLabel lblNewLabel_1_6 = new JLabel("Note Exm");
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1_6.setBounds(29, 261, 91, 30);
		panel_1_1_1.add(lblNewLabel_1_6);
		//JTextField() de nom
		textnom = new JTextField();
		textnom.setFont(new Font("Tahoma", Font.ITALIC, 15));
		textnom.setBounds(169, 36, 156, 19);
		panel_1_1_1.add(textnom);
		textnom.setColumns(10);
		//JTextField() de prenom
		textpr = new JTextField();
		textpr.setFont(new Font("Tahoma", Font.ITALIC, 15));
		textpr.setColumns(10);
		textpr.setBounds(169, 76, 156, 19);
		panel_1_1_1.add(textpr);
		//JTextField() de cin
		textcin = new JTextField();
		textcin.setFont(new Font("Tahoma", Font.ITALIC, 15));
		textcin.setColumns(10);
		textcin.setBounds(169, 116, 156, 19);
		panel_1_1_1.add(textcin);
		//JTextField() de note ds
		textds = new JTextField();
		textds.setFont(new Font("Tahoma", Font.ITALIC, 15));
		textds.setColumns(10);
		textds.setBounds(169, 233, 156, 19);
		panel_1_1_1.add(textds);
		//JTextField() de note examen
		textex = new JTextField();
		textex.setFont(new Font("Tahoma", Font.ITALIC, 15));
		textex.setColumns(10);
		textex.setBounds(169, 267, 156, 19);
		panel_1_1_1.add(textex);
		//JComboBox
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"effectuer une s\u00E9lection", "2GT1", "2GT2", "2GT3"}));
		comboBox.setBounds(169, 153, 156, 21);
		panel_1_1_1.add(comboBox);
		//JComboBox
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"effectuer une s\u00E9lection", "JAVA", "UML", "CSS", "JS", "HTML", "C++", "BD", "PYTHON"}));
		comboBox_1.setBounds(169, 193, 156, 21);
		panel_1_1_1.add(comboBox_1);
		// note final
		JLabel lblNewLabel_1_5_1 = new JLabel("Note final");
		lblNewLabel_1_5_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1_5_1.setBounds(426, 108, 91, 30);
		panel_1_1_1.add(lblNewLabel_1_5_1);
		// resultat note final
		r = new JTextField();
		r.setFont(new Font("Tahoma", Font.ITALIC, 15));
		r.setColumns(10);
		r.setBounds(394, 146, 156, 19);
		panel_1_1_1.add(r);
		//new jPanel
		JPanel panel_1_1_1_1 = new JPanel();
		panel_1_1_1_1.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(176, 224, 230)));//bordure tableau
		panel_1_1_1_1.setBackground(new Color(240, 255, 255));
		panel_1_1_1_1.setBounds(676, 167, 627, 347);
		panel_1.add(panel_1_1_1_1);
		panel_1_1_1_1.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(24, 28, 578, 293);
		panel_1_1_1_1.add(scrollPane);
		//table des donnees 
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nom", "Prenom", "Cin", "Groupe", "Mati\u00E8re", "Note Ds", "Note Exm"
			}
		));
		scrollPane.setViewportView(table);
		//new jPanel
		JPanel panel_1_1_1_2 = new JPanel();
		panel_1_1_1_2.setLayout(null);
		panel_1_1_1_2.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(176, 224, 230)));
		panel_1_1_1_2.setBackground(new Color(240, 255, 255));
		panel_1_1_1_2.setBounds(39, 548, 1267, 91);
		panel_1.add(panel_1_1_1_2);
		
		JButton btnNewButton_1 = new JButton("Ajouter");
		btnNewButton_1.addActionListener(new ActionListener() {
			//button ajouter
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel model= (DefaultTableModel) table.getModel();
				model.addRow(new Object[]{
					textnom.getText(),// get pour la recuperation des donnes
					textpr.getText(),
					textcin.getText(),
					comboBox.getSelectedItem(),// getSelectedItem pour la recuperation a partir de liste 
					comboBox_1.getSelectedItem(),
					textds.getText(),
					textex.getText(),
					
				});
		
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(98, 28, 143, 35);
		panel_1_1_1_2.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("R\u00E9inisialiser");
		btnNewButton_2.addActionListener(new ActionListener() {
			//button reinisialliser
			public void actionPerformed(ActionEvent e) {
				textnom.setText("");// methode pour retourner a l'etat initial
				textpr.setText("");
				textcin.setText("");
				textds.setText("");
				textex.setText("");
				comboBox.setSelectedItem("effectuer une s�lection");
				comboBox_1.setSelectedItem("effectuer une s�lection");
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(301, 28, 143, 35);
		panel_1_1_1_2.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Supprimer");
		btnNewButton_3.addActionListener(new ActionListener() {
			//button supprimer
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if (table.getSelectedRow()== -1) {
					if(table.getRowCount()== 0) {
						JOptionPane.showMessageDialog(null, " non donnees a supprimer","gestion de note",JOptionPane.OK_OPTION);//si la table est vide
						
					}else {
						JOptionPane.showMessageDialog(null, " selectionner ligne a supprimer","gestion de note",JOptionPane.OK_OPTION);//si on n'est pas selectionner une ligne
					}
					}else {
						model.removeRow(table.getSelectedRow());//supprimer ligne selectionner
					}
				}			
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3.setBounds(683, 28, 143, 35);
		panel_1_1_1_2.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Sortir");
		btnNewButton_4.addActionListener(new ActionListener() {
			//button sortir
			public void actionPerformed(ActionEvent e) {
				frame=new JFrame();
				if(JOptionPane.showConfirmDialog(frame, "voulez vous quitter !!","Gestion de note",
						JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
				
				
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_4.setBounds(865, 28, 143, 35);
		panel_1_1_1_2.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Calculer");
		btnNewButton_5.addActionListener(new ActionListener() {
			//button calculer
			public void actionPerformed(ActionEvent e) {
				int num1=Integer.parseInt(textds.getText());
				int num2=Integer.parseInt(textex.getText());
				double num3=((num1*0.3)+(num2*0.7));//calculer note finale
				r.setText(""+num3);
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_5.setBounds(1053, 28, 143, 35);
		panel_1_1_1_2.add(btnNewButton_5);
		
		JButton btnNewButton_3_1 = new JButton("Imprimer");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			//button imprimer
			public void actionPerformed(ActionEvent arg0) {
				try {
					table.print();
				}
				catch(java.awt.print.PrinterException e){
					System.err.format("aucune imprimante trouv�e ", e.getMessage());
					
				}
				
			}
		});
		btnNewButton_3_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3_1.setBounds(495, 28, 143, 35);
		panel_1_1_1_2.add(btnNewButton_3_1);
	}
}
